package net.blackhole.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class ScreenMixin {
    private static final Identifier BG = Identifier.of("blackhole", "textures/gui/bg.png");
    private static final Identifier SWIRL = Identifier.of("blackhole", "textures/gui/swirl.png");
    // centro do buraco negro (fração da tela)
    private static final float CX = 0.754f, CY = 0.470f;

    @Inject(method = "renderPanoramaBackground", at = @At("HEAD"), cancellable = true)
    private void blackhole$draw(DrawContext ctx, float delta, CallbackInfo ci) {
        if (!((Object) this instanceof TitleScreen)) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        float t = (System.currentTimeMillis() % 3_600_000L) / 1000f;

        blit(ctx, BG, w, h, 0xFFFFFFFF);
        float cx = w * CX, cy = h * CY;
        layer(ctx, w, h, cx, cy, (float) Math.sin(t * 0.7) * 0.06f, 0.50f);
        layer(ctx, w, h, cx, cy, (float) Math.sin(t * 0.45 + 2.0) * -0.09f, 0.35f);
        ci.cancel();
    }

    private static void layer(DrawContext ctx, int w, int h, float cx, float cy, float ang, float alpha) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.rotate(ang);
        m.translate(-cx, -cy);
        blit(ctx, SWIRL, w, h, ((int) (alpha * 255) << 24) | 0xFFFFFF);
        m.popMatrix();
    }

    private static void blit(DrawContext ctx, Identifier id, int w, int h, int color) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, 0, 0, 0f, 0f, w, h, 1920, 1080, 1920, 1080, color);
    }
}
